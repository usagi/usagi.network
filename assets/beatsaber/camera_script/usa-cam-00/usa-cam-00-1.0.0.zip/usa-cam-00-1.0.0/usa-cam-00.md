# 利用規約

## License
- この作品は、[MIT License](https://opensource.org/licenses/MIT) のもと提供されます。

## 作者の方針（法的拘束力はありませんが、ご理解とご配慮をお願いします）
以下のような目的での使用については、作者として望んでおりません：

- 政治的活動（選挙運動など）への使用
- 宗教的活動・布教への使用
- 明確な性的表現との関連（アダルトコンテンツ等）への使用
- 過度な暴力的表現を伴う使用

（以上はあくまで作者個人の希望であり、法的には禁止しておりません）

## Author

- Dr.USAGI / USAGI.NETWORK (Official-website: https://usagi.network)
